/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_151(unsigned x)
{
    return x + 3251079496U;
}

unsigned addval_492(unsigned x)
{
    return x + 3284633960U;
}

void setval_256(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_112(unsigned x)
{
    return x + 3347662883U;
}

void setval_127(unsigned *p)
{
    *p = 1211869855U;
}

unsigned getval_425()
{
    return 2425393752U;
}

unsigned addval_217(unsigned x)
{
    return x + 3281031256U;
}

void setval_161(unsigned *p)
{
    *p = 2864943192U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_289()
{
    return 113497801U;
}

void setval_103(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_284(unsigned x)
{
    return x + 3767126235U;
}

void setval_220(unsigned *p)
{
    *p = 2428602585U;
}

void setval_357(unsigned *p)
{
    *p = 3284830234U;
}

unsigned addval_238(unsigned x)
{
    return x + 566479497U;
}

void setval_493(unsigned *p)
{
    *p = 3397964882U;
}

unsigned getval_325()
{
    return 3682124169U;
}

void setval_480(unsigned *p)
{
    *p = 3525891721U;
}

void setval_141(unsigned *p)
{
    *p = 3767093533U;
}

void setval_282(unsigned *p)
{
    *p = 3675832713U;
}

unsigned addval_130(unsigned x)
{
    return x + 3675838089U;
}

unsigned getval_474()
{
    return 2464188744U;
}

unsigned getval_179()
{
    return 3527988873U;
}

unsigned addval_331(unsigned x)
{
    return x + 3677935241U;
}

unsigned getval_459()
{
    return 3676883593U;
}

unsigned getval_175()
{
    return 3372275337U;
}

void setval_434(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_391()
{
    return 3375939977U;
}

unsigned getval_296()
{
    return 3284240577U;
}

void setval_479(unsigned *p)
{
    *p = 3676357001U;
}

void setval_476(unsigned *p)
{
    *p = 3375942281U;
}

unsigned getval_271()
{
    return 3227566473U;
}

unsigned addval_351(unsigned x)
{
    return x + 3767101590U;
}

unsigned getval_122()
{
    return 3286272328U;
}

unsigned addval_191(unsigned x)
{
    return x + 3531917993U;
}

unsigned getval_221()
{
    return 2447411528U;
}

unsigned addval_263(unsigned x)
{
    return x + 3375942285U;
}

unsigned getval_433()
{
    return 3676357000U;
}

unsigned addval_344(unsigned x)
{
    return x + 3531921033U;
}

unsigned getval_155()
{
    return 2160187017U;
}

unsigned getval_334()
{
    return 3534015113U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
